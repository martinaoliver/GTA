onetoten = range(1,6) 
total = 1
for count in onetoten: 
    total *= count

print ("Factorial of 5 =", total)
