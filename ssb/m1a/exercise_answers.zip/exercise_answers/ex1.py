name = "Lenka"

print (name)

print (name, end='')

print ("Hello", name)
