

class Hello: 
    def sayHi(self): 
        print ('Hello world') 
