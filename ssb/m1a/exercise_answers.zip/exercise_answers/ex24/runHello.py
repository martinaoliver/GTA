from hello import Hello	

h = Hello() 
h.sayHi() 

