num = 1
total = 1
while num <= 5:
        total *= num
        num += 1

print ("Factorial of 5 =", total)

