from Atom import Atom

at = Atom("C",0.0,1.0,2.0)
print (at)
